// Estante Aberta - servidor sem dependências obrigatórias (Node 18+)
const http=require("http"),fs=require("fs"),path=require("path"),crypto=require("crypto");
try{for(const l of fs.readFileSync(path.join(__dirname,".env"),"utf8").split(/\r?\n/)){const m=l.match(/^\s*([A-Z_]+)\s*=\s*(.*)\s*$/);if(m&&!(m[1] in process.env))process.env[m[1]]=m[2].replace(/^["']|["']$/g,"")}}catch{}
const PORT=+process.env.PORT||3000,BASE=(process.env.BASE_URL||"http://localhost:"+PORT).replace(/\/$/,"");
const FILE=path.join(__dirname,"data","db.json"),PUB=path.join(__dirname,"public");
const rid=n=>crypto.randomBytes(n).toString("hex"),sha=s=>crypto.createHash("sha256").update(s).digest("hex");
let DB;
try{DB=JSON.parse(fs.readFileSync(FILE,"utf8"))}catch{DB={admin:null,books:JSON.parse(fs.readFileSync(path.join(__dirname,"data","seed.json"),"utf8")),ratings:{},suggestions:[],resets:[]}}
const save=()=>{const t=FILE+".tmp";fs.writeFileSync(t,JSON.stringify(DB,null,1));fs.renameSync(t,FILE)};
const hp=(pw,salt=rid(16))=>({salt,h:crypto.scryptSync(pw,salt,64).toString("hex")});
const chk=(pw,a)=>{const x=Buffer.from(crypto.scryptSync(pw,a.salt,64).toString("hex")),y=Buffer.from(a.h);return x.length===y.length&&crypto.timingSafeEqual(x,y)};
// administrador inicial
if(!DB.admin){
  const email=(process.env.ADMIN_EMAIL||"admin@example.com").toLowerCase();
  let pw=process.env.ADMIN_PASSWORD,gen=false;
  if(!pw||pw.length<8){pw=rid(6);gen=true}
  DB.admin={email,...hp(pw)};save();
  console.log("\n== Administrador criado ==\nE-mail:",email);
  if(gen)console.log("Senha temporária:",pw,"(anote e troque usando 'Esqueci a senha')");
  console.log("");
}
const sessions=new Map(),tries=new Map();
const limited=(k,max,ms)=>{const n=Date.now(),t=(tries.get(k)||[]).filter(x=>n-x<ms);t.push(n);tries.set(k,t);return t.length>max};
const cookies=r=>Object.fromEntries((r.headers.cookie||"").split(";").map(c=>c.trim().split(/=(.*)/s).slice(0,2)).filter(a=>a[0]));
const secure=BASE.startsWith("https")?"; Secure":"";
const setCk=(res,k,v,age)=>{const a=res.getHeader("Set-Cookie")||[];res.setHeader("Set-Cookie",[].concat(a,`${k}=${v}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${age}${secure}`))};
const send=(res,c,o)=>{res.writeHead(c,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"}).end(JSON.stringify(o))};
const readBody=req=>new Promise((ok,no)=>{let b="";req.on("data",d=>{b+=d;if(b.length>1e5){no(new Error("grande"));req.destroy()}});req.on("end",()=>{try{ok(b?JSON.parse(b):{})}catch(e){no(e)}})});
const isAdmin=req=>{const t=cookies(req).sid,e=sessions.get(t);if(e&&e>Date.now())return true;sessions.delete(t);return false};
const str=(v,n)=>typeof v==="string"?v.trim().slice(0,n):"";
function cleanBook(b){
  const o={t:str(b.t,120),a:str(b.a,120),c:str(b.c,60),d:str(b.d,1000),y:Math.trunc(+b.y),p:Math.trunc(+b.p),col:/^#[0-9a-f]{6}$/i.test(b.col)?b.col:"#27506b",link:/^https:\/\//.test(b.link||"")?String(b.link).slice(0,500):""};
  return o.t&&o.a&&o.c&&o.d&&Number.isFinite(o.y)&&o.p>0?o:null}
async function mail(to,subject,text){
  try{if(!process.env.SMTP_HOST)throw new Error("SMTP não configurado");const nm=require("nodemailer");
    await nm.createTransport({host:process.env.SMTP_HOST,port:+process.env.SMTP_PORT||587,secure:process.env.SMTP_SECURE==="true",auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}})
      .sendMail({from:process.env.MAIL_FROM||process.env.SMTP_USER,to,subject,text});return true}
  catch(e){console.log("[e-mail não enviado:",e.message,"]\nPara:",to,"\n"+subject+"\n"+text+"\n");return false}}
const rates=()=>{const r={};for(const k in DB.ratings){const v=Object.values(DB.ratings[k]);if(v.length)r[k]={s:v.reduce((a,b)=>a+b,0),n:v.length}}return r};

async function api(req,res,u){
  const ip=req.socket.remoteAddress,m=req.method,p=u.pathname.replace(/^\/api\//,"");
  if(m!=="GET"&&!(req.headers["content-type"]||"").startsWith("application/json"))return send(res,415,{error:"Tipo inválido"});
  const b=m==="GET"||m==="DELETE"?{}:await readBody(req);
  if(p==="books"&&m==="GET")return send(res,200,{books:DB.books});
  if(p==="ratings"&&m==="GET"){let v=cookies(req).vid;if(!/^[0-9a-f]{32}$/.test(v||"")){v=rid(16);setCk(res,"vid",v,31536000)}
    const mine={};for(const k in DB.ratings)if(DB.ratings[k][v])mine[k]=DB.ratings[k][v];return send(res,200,{ratings:rates(),mine})}
  if(p==="rate"&&m==="POST"){const v=cookies(req).vid,k=str(b.key,80),s=Math.trunc(+b.stars);
    if(!/^[0-9a-f]{32}$/.test(v||"")||!DB.books.some(x=>x.id===k)||!(s>=1&&s<=5))return send(res,400,{error:"Dados inválidos"});
    if(limited("r"+ip,60,6e4))return send(res,429,{error:"Muitas tentativas"});
    (DB.ratings[k]=DB.ratings[k]||{})[v]=s;save();return send(res,200,{ok:1})}
  if(p==="suggest"&&m==="POST"){const t=str(b.text,300);if(!t)return send(res,400,{error:"Texto vazio"});
    if(limited("s"+ip,5,36e5))return send(res,429,{error:"Muitas sugestões. Tente mais tarde."});
    DB.suggestions.unshift({id:rid(6),text:t,name:str(b.name,60),at:Date.now()});DB.suggestions=DB.suggestions.slice(0,200);save();return send(res,200,{ok:1})}
  if(p==="admin/session")return send(res,200,{admin:isAdmin(req)});
  if(p==="admin/login"&&m==="POST"){
    if(limited("l"+ip,8,9e5))return send(res,429,{error:"Muitas tentativas. Aguarde 15 minutos."});
    if(str(b.email,200).toLowerCase()===DB.admin.email&&typeof b.password==="string"&&chk(b.password,DB.admin)){
      const t=rid(24);sessions.set(t,Date.now()+864e5);setCk(res,"sid",t,86400);return send(res,200,{ok:1})}
    return send(res,401,{error:"E-mail ou senha incorretos."})}
  if(p==="admin/logout"&&m==="POST"){sessions.delete(cookies(req).sid);setCk(res,"sid","",0);return send(res,200,{ok:1})}
  if(p==="admin/forgot"&&m==="POST"){
    if(limited("f"+ip,5,36e5))return send(res,429,{error:"Muitas tentativas."});
    if(str(b.email,200).toLowerCase()===DB.admin.email){const t=rid(24);DB.resets=[{h:sha(t),exp:Date.now()+36e5}];save();
      await mail(DB.admin.email,"Redefinir senha - Estante Aberta","Para criar uma nova senha, abra o link (vale por 1 hora):\n"+BASE+"/?reset="+t+"\n\nSe não foi você, ignore esta mensagem.")}
    return send(res,200,{ok:1})}
  if(p==="admin/reset"&&m==="POST"){
    if(limited("x"+ip,10,36e5))return send(res,429,{error:"Muitas tentativas."});
    const h=sha(str(b.token,100)),r=DB.resets.find(x=>x.h===h&&x.exp>Date.now());
    if(!r||typeof b.password!=="string"||b.password.length<8)return send(res,400,{error:"Link inválido ou senha curta demais."});
    DB.admin={email:DB.admin.email,...hp(b.password)};DB.resets=[];save();sessions.clear();return send(res,200,{ok:1})}
  if(!p.startsWith("admin/"))return send(res,404,{error:"Não encontrado"});
  if(!isAdmin(req))return send(res,401,{error:"Faça login"});
  const id=p.split("/")[2];
  if(p==="admin/suggestions"&&m==="GET")return send(res,200,{items:DB.suggestions});
  if(p.startsWith("admin/suggestions/")&&m==="DELETE"){DB.suggestions=DB.suggestions.filter(x=>x.id!==id);save();return send(res,200,{ok:1})}
  if(p==="admin/books"&&m==="POST"){const o=cleanBook(b);if(!o)return send(res,400,{error:"Preencha todos os campos."});
    o.id=(o.t.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"")||"livro")+"-"+rid(2);DB.books.push(o);save();return send(res,200,o)}
  if(p.startsWith("admin/books/")&&m==="POST"){const i=DB.books.findIndex(x=>x.id===id),o=cleanBook(b);
    if(i<0||!o)return send(res,400,{error:"Dados inválidos"});DB.books[i]={...o,id};save();return send(res,200,DB.books[i])}
  if(p.startsWith("admin/books/")&&m==="DELETE"){DB.books=DB.books.filter(x=>x.id!==id);delete DB.ratings[id];save();return send(res,200,{ok:1})}
  send(res,404,{error:"Não encontrado"})}

const MIME={".html":"text/html; charset=utf-8",".css":"text/css; charset=utf-8",".js":"text/javascript; charset=utf-8",".svg":"image/svg+xml",".png":"image/png",".ico":"image/x-icon"};
http.createServer(async(req,res)=>{
  res.setHeader("X-Content-Type-Options","nosniff");res.setHeader("Referrer-Policy","same-origin");
  res.setHeader("Content-Security-Policy","default-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'");
  try{const u=new URL(req.url,BASE);
    if(u.pathname.startsWith("/api/"))return await api(req,res,u);
    if(req.method!=="GET"&&req.method!=="HEAD")return send(res,405,{error:"Método inválido"});
    const f=path.join(PUB,path.normalize(decodeURIComponent(u.pathname==="/"?"/index.html":u.pathname)));
    if(!f.startsWith(PUB+path.sep)||!fs.existsSync(f)||!fs.statSync(f).isFile()){res.writeHead(404,{"Content-Type":"text/plain; charset=utf-8"});return res.end("Página não encontrada")}
    res.writeHead(200,{"Content-Type":MIME[path.extname(f)]||"application/octet-stream"});fs.createReadStream(f).pipe(res)}
  catch(e){if(!res.headersSent)send(res,400,{error:"Requisição inválida"});else res.end()}
}).listen(PORT,()=>console.log("Estante Aberta em",BASE));
