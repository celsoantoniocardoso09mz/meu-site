const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const safeUrl=u=>/^https:\/\//.test(u||"")?u:"";
const norm=s=>s.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase();
const lget=(k,d)=>{try{return JSON.parse(localStorage.getItem(k)||"")}catch(e){return d}};
const lset=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};
const api=async(p,m="GET",b)=>{
  const r=await fetch("/api/"+p,{method:m,credentials:"same-origin",headers:m==="GET"?{}:{"Content-Type":"application/json"},body:m==="GET"?undefined:JSON.stringify(b||{})});
  const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error||"Erro inesperado");return j};
let CAT=[],agg={},mine={},editId=null,cat="Todos",query="",onlyFav=false,favs=lget("favs",[]),resetToken=null;
const yr=b=>b.y<0?"séc. V a.C.":b.y;
const gut=b=>safeUrl(b.link)||"https://www.gutenberg.org/ebooks/search/?query="+encodeURIComponent(b.t+" "+b.a);
const wiki=b=>"https://pt.wikisource.org/w/index.php?search="+encodeURIComponent(b.t);
const avg=b=>{const a=agg[b.id];return a&&a.n?a.s/a.n:0};
function stars(b){const a=agg[b.id],m=mine[b.id]||0;
 return `<div class="stars"><span>${[1,2,3,4,5].map(i=>`<button class="st${i<=m?" on":""}" data-s="${i}" data-k="${esc(b.id)}" aria-label="Dar ${i} estrelas a ${esc(b.t)}">★</button>`).join("")}</span><small>${a&&a.n?(a.s/a.n).toFixed(1)+" ("+a.n+")":"sem notas"}</small></div>`}
function card(b){const f=favs.includes(b.id);return `
 <article class="card">
  <button class="cover" style="background:linear-gradient(160deg,${/^#[0-9a-f]{6}$/i.test(b.col)?b.col:"#27506b"},#0d1520 140%)" data-k="${esc(b.id)}" aria-label="Ver detalhes de ${esc(b.t)}"><b>${esc(b.t)}</b><span>${esc(b.a)}</span></button>
  <div class="meta"><h3>${esc(b.t)}</h3><p>${esc(b.a)}, ${yr(b)} · ${esc(b.p)} p.</p></div>
  ${stars(b)}
  <div class="row"><a class="dl" href="${esc(gut(b))}" target="_blank" rel="noopener">Baixar</a><a class="fav" href="${esc(wiki(b))}" target="_blank" rel="noopener" style="flex:1!important">Ler</a>
  <button class="fav" data-f="${esc(b.id)}" aria-pressed="${f}" aria-label="Favoritar ${esc(b.t)}">${f?"♥":"♡"}</button></div>
 </article>`}
function chips(){const cats=["Todos",...new Set(CAT.map(b=>b.c))];if(!cats.includes(cat))cat="Todos";
 $("#chips").innerHTML=cats.map(c=>`<button class="chip" aria-pressed="${c===cat}" data-c="${esc(c)}">${esc(c)}</button>`).join("");
 $("#cl").innerHTML=cats.slice(1).map(c=>`<option value="${esc(c)}">`).join("")}
function render(){
 const list=CAT.filter(b=>(cat==="Todos"||b.c===cat)&&(!onlyFav||favs.includes(b.id))&&norm(b.t+" "+b.a).includes(query));
 $("#count").textContent=list.length+(list.length===1?" livro encontrado":" livros encontrados");
 $("#grid").innerHTML=list.length?list.map(card).join(""):`<p class="empty">Nenhum livro encontrado.</p>`;
 const rated=CAT.filter(b=>avg(b)>0).sort((a,b)=>avg(b)-avg(a)).slice(0,4);
 $("#rn").textContent=rated.length?"Os mais bem avaliados pelos leitores.":"Seleção da casa. Avalie os livros e os favoritos dos leitores aparecem aqui.";
 $("#rg").innerHTML=(rated.length?rated:CAT.slice(0,4)).map(card).join("");
}
async function loadBooks(){CAT=(await api("books")).books;chips();render()}
async function loadRatings(){const r=await api("ratings");agg=r.ratings;mine=r.mine;render()}
$("#chips").onclick=e=>{const c=e.target.dataset.c;if(c){cat=c;chips();render()}};
$("#q").oninput=e=>{query=norm(e.target.value);render()};
$("#fv").onclick=()=>{onlyFav=!onlyFav;$("#fv").setAttribute("aria-pressed",onlyFav);$("#fv").textContent=onlyFav?"Ver todos":"Favoritos";location.hash="catalogo";render()};
document.body.addEventListener("click",async e=>{
 const st=e.target.closest(".st"),f=e.target.closest(".fav[data-f]"),c=e.target.closest(".cover"),x=e.target.closest(".xc");
 if(x)x.closest("dialog").close();
 if(f){const t=f.dataset.f;favs=favs.includes(t)?favs.filter(y=>y!==t):[...favs,t];lset("favs",favs);render()}
 if(st){try{await api("rate","POST",{key:st.dataset.k,stars:+st.dataset.s});await loadRatings()}catch(err){}}
 if(c){const b=CAT.find(y=>y.id===c.dataset.k);if(!b)return;$("#dt").textContent=b.t;$("#da").textContent=b.a+", "+yr(b);$("#dd").textContent=b.d;
  $("#dl").innerHTML=`<a class="dl" href="${esc(gut(b))}" target="_blank" rel="noopener" style="background:var(--accent);color:var(--accent-ink)">Baixar livro</a><a class="sec" href="${esc(wiki(b))}" target="_blank" rel="noopener">Ler online</a><button class="sec xc">Fechar</button>`;
  $("#dlg").showModal()}
});
$("#dlg").onclick=e=>{if(e.target.id==="dlg")e.target.close()};
$("#adm").onclick=e=>{if(e.target.id==="adm")e.target.close()};

/* sugestões */
$("#ss").onclick=async()=>{const t=$("#st").value.trim();if(!t)return;
 try{await api("suggest","POST",{text:t,name:$("#sn").value});$("#st").value="";$("#sm").textContent="Sugestão enviada. Obrigado!"}
 catch(err){$("#sm").textContent=err.message}};

/* administração */
const panes=["p1","p2","p3","p4"],show=id=>panes.forEach(p=>$("#"+p).hidden=p!==id),say=t=>$("#am").textContent=t;
async function openAdmin(){say("");$("#adm").showModal();
 try{if((await api("admin/session")).admin){show("p4");panel()}else show("p2")}catch(e){show("p2")}}
$("#ad").onclick=openAdmin;
$("#b2").onclick=async()=>{try{await api("admin/login","POST",{email:$("#e2").value,password:$("#w2").value});$("#w2").value="";say("");show("p4");panel()}catch(e){say(e.message)}};
$("#l2").onclick=()=>{say("");show("p3")};$("#l3").onclick=()=>{say("");show("p2")};
$("#b3").onclick=async()=>{try{await api("admin/forgot","POST",{email:$("#e3").value});say("Se o e-mail estiver correto, você receberá o link em instantes.")}catch(e){say(e.message)}};
$("#b1").onclick=async()=>{try{await api("admin/reset","POST",{token:resetToken,password:$("#w1").value});history.replaceState(null,"","/");resetToken=null;$("#w1").value="";say("Senha alterada. Faça login.");show("p2")}catch(e){say(e.message)}};
$("#lo").onclick=async()=>{try{await api("admin/logout","POST")}catch(e){}$("#adm").close()};
async function panel(){
 $("#al").innerHTML=CAT.map((b,i)=>`<div><span><b>${esc(b.t)}</b><br><small>${esc(b.a)}</small></span><button data-e="${i}">Editar</button><button data-d="${i}">Excluir</button></div>`).join("");
 try{const s=(await api("admin/suggestions")).items;
  $("#sl").innerHTML=s.map(v=>`<div><span>${esc(v.text)}<br><small>${esc(v.name||"anônimo")}</small></span><button data-s="${esc(v.id)}">Apagar</button></div>`).join("")||"<div><span>Nenhuma sugestão ainda.</span></div>"}catch(e){}}
function resetForm(){editId=null;$("#af").reset();$("#fk").value="#27506b";$("#fs").textContent="Adicionar livro";$("#fx").hidden=true}
$("#fx").onclick=resetForm;
$("#adm").addEventListener("click",async e=>{
 const be=e.target.closest("[data-e]"),bd=e.target.closest("[data-d]"),bs=e.target.closest("[data-s]");
 if(be){const b=CAT[+be.dataset.e];editId=b.id;
  $("#ft").value=b.t;$("#fa").value=b.a;$("#fc").value=b.c;$("#fy").value=b.y;$("#fp").value=b.p;$("#fk").value=b.col;$("#fg").value=b.link||"";$("#fd").value=b.d;
  $("#fs").textContent="Salvar alterações";$("#fx").hidden=false;$("#ft").focus()}
 if(bd){if(!bd.classList.contains("arm")){bd.classList.add("arm");bd.textContent="Confirmar";return}
  try{await api("admin/books/"+CAT[+bd.dataset.d].id,"DELETE");await loadBooks();await loadRatings();panel()}catch(err){say(err.message)}}
 if(bs){try{await api("admin/suggestions/"+bs.dataset.s,"DELETE");panel()}catch(err){say(err.message)}}
});
$("#af").onsubmit=async e=>{e.preventDefault();$("#fs").disabled=true;
 const data={t:$("#ft").value,a:$("#fa").value,c:$("#fc").value,y:$("#fy").value,p:$("#fp").value,col:$("#fk").value,d:$("#fd").value,link:$("#fg").value};
 try{await api(editId?"admin/books/"+editId:"admin/books","POST",data);resetForm();say("Salvo com sucesso.");await loadBooks();panel()}
 catch(err){say(err.message)}
 $("#fs").disabled=false};

chips();
loadBooks().then(loadRatings).catch(()=>{$("#count").textContent="Não foi possível carregar o catálogo."});
const rt=new URLSearchParams(location.search).get("reset");
if(rt){resetToken=rt;$("#adm").showModal();show("p1")}
