# Estante Aberta

Biblioteca de livros em domínio público com menu, estrelas de avaliação, caixa de sugestões,
download/leitura online e área de administrador (login com senha e recuperação por e-mail).

## Instalar e rodar
1. Instale o Node.js 18 ou mais novo (nodejs.org).
2. Nesta pasta, copie `.env.example` para `.env` e preencha (principalmente `ADMIN_EMAIL`,
   `ADMIN_PASSWORD` e `BASE_URL`).
3. Para enviar e-mails de recuperação: `npm install` (instala o `nodemailer`) e preencha as linhas `SMTP_*`.
4. Rode: `npm start` e abra http://localhost:3000

Sem SMTP configurado, o link de recuperação de senha aparece no terminal do servidor.

## Administrador
- O administrador é criado na primeira execução, com `ADMIN_EMAIL` e `ADMIN_PASSWORD`.
  Se a senha não for definida, o servidor gera uma e mostra no terminal.
- Clique em **Admin** no topo do site, entre e use o painel para adicionar, editar e excluir livros
  e ler ou apagar as sugestões dos leitores.
- **Esqueci a senha**: o sistema envia um link (válido por 1 hora) para o e-mail do administrador.
- Para recomeçar o acesso do zero, pare o servidor e apague o campo `admin` de `data/db.json`
  (ou o arquivo inteiro, se aceitar perder livros e notas). Na próxima execução o administrador é recriado.

## Publicar na internet
Use um serviço que rode Node.js (Render, Railway, Fly.io ou um VPS). Defina as variáveis do `.env`
no painel do serviço, use HTTPS e coloque `BASE_URL` com o endereço final.
Os dados ficam em `data/db.json`: use um disco persistente e faça cópias de segurança desse arquivo.

## Segurança já incluída
Senhas guardadas com scrypt, sessão em cookie HttpOnly/SameSite, limite de tentativas de login,
validação de todos os campos, proteção contra XSS e cabeçalhos de segurança (CSP).

## Observações
- Cada visitante avalia cada livro uma vez (identificado por cookie; pode mudar a nota).
- Cadastre apenas obras em domínio público ou com licença de distribuição.
